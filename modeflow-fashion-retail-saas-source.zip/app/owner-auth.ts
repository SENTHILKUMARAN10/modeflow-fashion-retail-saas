import { env } from "cloudflare:workers";
const bytes=new TextEncoder();
function config(){return env as unknown as {OWNER_PIN?:string;OWNER_SESSION_SECRET?:string}}
async function sign(value:string){const secret=config().OWNER_SESSION_SECRET;if(!secret)return "";const key=await crypto.subtle.importKey("raw",bytes.encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);const out=await crypto.subtle.sign("HMAC",key,bytes.encode(value));return Array.from(new Uint8Array(out)).map(x=>x.toString(16).padStart(2,"0")).join("")}
export async function validPin(pin:string){const expected=config().OWNER_PIN||"",[a,b]=await Promise.all([crypto.subtle.digest("SHA-256",bytes.encode(pin)),crypto.subtle.digest("SHA-256",bytes.encode(expected))]);const x=new Uint8Array(a),y=new Uint8Array(b);if(x.length!==y.length)return false;let d=0;for(let i=0;i<x.length;i++)d|=x[i]^y[i];return d===0&&expected.length>0}
export async function sessionToken(){return sign("prawin-owner")}
export async function authorized(req:Request){const raw=req.headers.get("cookie")||"",token=raw.split(';').map(x=>x.trim()).find(x=>x.startsWith('tk_owner='))?.slice(9)||"";return token!==""&&token===await sessionToken()}
