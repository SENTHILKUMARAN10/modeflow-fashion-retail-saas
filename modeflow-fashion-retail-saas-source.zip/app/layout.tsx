import type { Metadata } from "next";
import "./globals.css";
import "./theme.css";

export const metadata: Metadata = { title: "Thatha Kadai — Billing & Accounts", description: "Stock, billing, customers and reports for Thatha Kadai" };

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
